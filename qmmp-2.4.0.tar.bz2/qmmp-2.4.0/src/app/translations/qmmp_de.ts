<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>BuiltinCommandLineOption</name>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="46"/>
        <source>Don&apos;t clear the playlist</source>
        <translation>Wiedergabeliste nicht löschen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="47"/>
        <source>Start playing current song</source>
        <translation>Aktuellen Titel abspielen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="48"/>
        <source>Pause current song</source>
        <translation>Aktuellen Titel pausieren</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="49"/>
        <source>Pause if playing, play otherwise</source>
        <translation>Wiedergabe pausieren oder fortsetzen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="50"/>
        <source>Stop current song</source>
        <translation>Aktuellen Titel stoppen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="51"/>
        <source>Display Jump to Track dialog</source>
        <translation>„Springe zu Titel“-Dialog anzeigen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="52"/>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="53"/>
        <source>Set playback volume (example: qmmp --volume 20)</source>
        <translation>Lautstärke der Wiedergabe einstellen (Beispiel: qmmp --volume 20)</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="54"/>
        <source>Print volume level</source>
        <translation>Lautstärke ausgeben</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="55"/>
        <source>Mute/Restore volume</source>
        <translation>Lautstärke stummschalten/wiederherstellen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="56"/>
        <source>Print mute status</source>
        <translation>Status der Stummschaltung ausgeben</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="57"/>
        <source>Skip forward in playlist</source>
        <translation>Nächsten Titel in Wiedergabeliste abspielen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="58"/>
        <source>Skip backwards in playlist</source>
        <translation>Vorherigen Titel in Wiedergabeliste abspielen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="59"/>
        <source>Show/hide application</source>
        <translation>Anwendung ein-/ausblenden</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="60"/>
        <source>Show main window</source>
        <translation>Hauptfenster anzeigen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="61"/>
        <source>Display Add File dialog</source>
        <translation>„Datei hinzufügen“-Dialog anzeigen</translation>
    </message>
    <message>
        <location filename="../builtincommandlineoption.cpp" line="62"/>
        <source>Display Add Directory dialog</source>
        <translation>„Verzeichnis hinzufügen“-Dialog anzeigen</translation>
    </message>
</context>
<context>
    <name>QMMPStarter</name>
    <message>
        <location filename="../qmmpstarter.cpp" line="154"/>
        <source>Unknown command</source>
        <translation>Unbekannter Befehl</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="531"/>
        <source>Usage: qmmp [options] [files]</source>
        <translation>Aufruf: qmmp [Optionen] [Dateien]</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="532"/>
        <source>Options:</source>
        <translation>Optionen:</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="538"/>
        <source>Start qmmp with the specified user interface</source>
        <translation>qmmp mit der angegebenen Benutzeroberfläche starten</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="539"/>
        <source>List all available user interfaces</source>
        <translation>Alle verfügbaren Benutzeroberflächen auflisten</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="540"/>
        <source>Don&apos;t start the application</source>
        <translation>Die Anwendung nicht starten</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="541"/>
        <source>Print debugging messages</source>
        <translation>Debugging-Nachrichten ausgeben</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="542"/>
        <source>Display this text and exit</source>
        <translation>Diesen Hilfetext anzeigen</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="543"/>
        <source>Print version number and exit</source>
        <translation>Versionsnummer ausgeben</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="545"/>
        <source>Home page: %1</source>
        <translation>Homepage: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="546"/>
        <source>Development page: %1</source>
        <translation>Entwicklungsseite: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="547"/>
        <source>Bug tracker: %1</source>
        <translation>Bug-Tracker: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="183"/>
        <location filename="../qmmpstarter.cpp" line="552"/>
        <source>Command Line Help</source>
        <translation>Befehlszeilenhilfe</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="565"/>
        <source>QMMP version: %1</source>
        <translation>Qmmp-Version: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="566"/>
        <source>Compiled with Qt version: %1</source>
        <translation>Kompiliert mit der Qt-Version %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="567"/>
        <source>Using Qt version: %1</source>
        <translation>Verwendet Qt-Version: %1</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="570"/>
        <source>Qmmp Version</source>
        <translation>Qmmp-Version</translation>
    </message>
    <message>
        <location filename="../qmmpstarter.cpp" line="587"/>
        <source>User Interfaces</source>
        <translation>Benutzeroberflächen</translation>
    </message>
</context>
</TS>
