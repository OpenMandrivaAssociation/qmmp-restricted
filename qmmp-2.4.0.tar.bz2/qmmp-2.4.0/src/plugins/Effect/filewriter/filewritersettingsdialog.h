/***************************************************************************
 *   Copyright (C) 2017-2026 by Ilya Kotov                                 *
 *   forkotov02@ya.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.         *
 ***************************************************************************/
#ifndef FILEWRITERSETTINGSDIALOG_H
#define FILEWRITERSETTINGSDIALOG_H

#include <QDialog>

namespace Ui {
class FileWriterSettingsDialog;
}

/**
    @author Ilya Kotov <forkotov02@ya.ru>
*/
class FileWriterSettingsDialog : public QDialog
{
Q_OBJECT
public:
    explicit FileWriterSettingsDialog(QWidget *parent = nullptr);

    ~FileWriterSettingsDialog();

public slots:
    virtual void accept() override;

private slots:
    void addTitleString(const QString &str);
    void on_dirButton_clicked();

private:
    Ui::FileWriterSettingsDialog *m_ui;

};

#endif
