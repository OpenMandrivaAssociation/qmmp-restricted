include(../../plugins.pri)

TARGET = $$PLUGINS_PREFIX/Effect/ladspa

HEADERS += ladspahost.h \
    effectladspafactory.h \
    ladspasettingsdialog.h \
    ladspaslider.h \
    ladspa.h \
    ladspahelper.h \
    ladspabutton.h

SOURCES += ladspahost.cpp \
    effectladspafactory.cpp \
    ladspasettingsdialog.cpp \
    ladspaslider.cpp \
    ladspahelper.cpp \
    ladspabutton.cpp

FORMS += \
    ladspasettingsdialog.ui

RESOURCES = translations/translations.qrc

LIBS += -L/usr/lib -I/usr/include
linux-g++|linux-g++-32|linux-g++-64:LIBS += -ldl

target.path = $$PLUGIN_DIR/Effect
INSTALLS += target
