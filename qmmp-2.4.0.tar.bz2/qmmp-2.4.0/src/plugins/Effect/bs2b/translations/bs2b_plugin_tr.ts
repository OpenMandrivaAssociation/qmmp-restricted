<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr">
<context>
    <name>Bs2bSettingsDialog</name>
    <message>
        <location filename="../bs2bsettingsdialog.ui" line="14"/>
        <source>BS2B Plugin Settings</source>
        <translation>BS2B Eklenti Ayarları</translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.ui" line="29"/>
        <source>Crossfeed level</source>
        <translation>Crossfeed seviyesi</translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.ui" line="42"/>
        <location filename="../bs2bsettingsdialog.ui" line="56"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.cpp" line="45"/>
        <source>C.Moy</source>
        <translation>C.Moy</translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.cpp" line="50"/>
        <source>J. Meier</source>
        <translation>J. Meier</translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.cpp" line="77"/>
        <source>%1 Hz, %2 us</source>
        <translation>%1 Hz, %2 us</translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.cpp" line="84"/>
        <source>%1 dB</source>
        <translation>%1 dB</translation>
    </message>
</context>
<context>
    <name>EffectBs2bFactory</name>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="31"/>
        <source>BS2B Plugin</source>
        <translation>BS2B Eklentisi</translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="50"/>
        <source>About BS2B Effect Plugin</source>
        <translation>BS2B Efekt Eklentisi Hakkında</translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="52"/>
        <source>This is the Qmmp plugin version of Boris Mikhaylov&apos;s headphone DSP effect &quot;Bauer stereophonic-to-binaural&quot;, abbreviated bs2b.</source>
        <translation>Bu eklenti Boris Mikhaylov&apos;un &quot;Bauer-stereophonic-to-binaural&quot;, kısaca bs2b, kulaklık DSP efektinin Qmmp sürümüdür.</translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="55"/>
        <source>Visit %1 for more details</source>
        <translation>Detaylar için %1 adresini ziyaret edin</translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="57"/>
        <source>Compiled against libbs2b-%1</source>
        <translation>libbs2b-%1&apos;e  dayanarak derlendi</translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="59"/>
        <source>Developers:</source>
        <translation>Geliştiriciler:</translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="60"/>
        <source>Ilya Kotov &amp;lt;forkotov02@ya.ru&amp;gt;</source>
        <translation>Ilya Kotov &amp;lt;forkotov02@ya.ru&amp;gt;</translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="61"/>
        <source>Sebastian Pipping &amp;lt;sebastian@pipping.org&amp;gt;</source>
        <translation>Sebastian Pipping &amp;lt;sebastian@pipping.org&amp;gt;</translation>
    </message>
</context>
</TS>
