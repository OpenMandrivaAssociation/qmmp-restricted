<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Bs2bSettingsDialog</name>
    <message>
        <location filename="../bs2bsettingsdialog.ui" line="14"/>
        <source>BS2B Plugin Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.ui" line="29"/>
        <source>Crossfeed level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.ui" line="42"/>
        <location filename="../bs2bsettingsdialog.ui" line="56"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.cpp" line="45"/>
        <source>C.Moy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.cpp" line="50"/>
        <source>J. Meier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.cpp" line="77"/>
        <source>%1 Hz, %2 us</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bs2bsettingsdialog.cpp" line="84"/>
        <source>%1 dB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EffectBs2bFactory</name>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="31"/>
        <source>BS2B Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="50"/>
        <source>About BS2B Effect Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="52"/>
        <source>This is the Qmmp plugin version of Boris Mikhaylov&apos;s headphone DSP effect &quot;Bauer stereophonic-to-binaural&quot;, abbreviated bs2b.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="55"/>
        <source>Visit %1 for more details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="57"/>
        <source>Compiled against libbs2b-%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="59"/>
        <source>Developers:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="60"/>
        <source>Ilya Kotov &amp;lt;forkotov02@ya.ru&amp;gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../effectbs2bfactory.cpp" line="61"/>
        <source>Sebastian Pipping &amp;lt;sebastian@pipping.org&amp;gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
