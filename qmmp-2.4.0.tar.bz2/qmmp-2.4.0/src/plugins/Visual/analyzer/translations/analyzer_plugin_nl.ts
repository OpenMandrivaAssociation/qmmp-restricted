<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl">
<context>
    <name>Analyzer</name>
    <message>
        <location filename="../analyzer.cpp" line="34"/>
        <source>Qmmp Analyzer</source>
        <translation>Qmmp-analyse</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="310"/>
        <source>Peaks</source>
        <translation>Pieken</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="313"/>
        <source>Refresh Rate</source>
        <translation>Verversingssnelheid</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="316"/>
        <source>50 fps</source>
        <translation>50 fps</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="317"/>
        <source>25 fps</source>
        <translation>25 fps</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="318"/>
        <source>10 fps</source>
        <translation>10 fps</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="319"/>
        <source>5 fps</source>
        <translation>5 fps</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="326"/>
        <source>Analyzer Falloff</source>
        <translation>Analyse-uitval</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="329"/>
        <location filename="../analyzer.cpp" line="343"/>
        <source>Slowest</source>
        <translation>Traagst</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="330"/>
        <location filename="../analyzer.cpp" line="344"/>
        <source>Slow</source>
        <translation>Traag</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="331"/>
        <location filename="../analyzer.cpp" line="345"/>
        <source>Medium</source>
        <translation>Normaal</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="332"/>
        <location filename="../analyzer.cpp" line="346"/>
        <source>Fast</source>
        <translation>Snel</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="333"/>
        <location filename="../analyzer.cpp" line="347"/>
        <source>Fastest</source>
        <translation>Snelst</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="340"/>
        <source>Peaks Falloff</source>
        <translation>Piekuitval</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="355"/>
        <location filename="../analyzer.cpp" line="357"/>
        <source>&amp;Full Screen</source>
        <translation>Beeld&amp;vullend</translation>
    </message>
    <message>
        <location filename="../analyzer.cpp" line="355"/>
        <location filename="../analyzer.cpp" line="357"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>AnalyzerColorWidget</name>
    <message>
        <location filename="../analyzercolorwidget.cpp" line="37"/>
        <source>Select Color</source>
        <translation>Kleur kiezen</translation>
    </message>
</context>
<context>
    <name>AnalyzerSettingsDialog</name>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="14"/>
        <source>Analyzer Plugin Settings</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="35"/>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="41"/>
        <source>Cells size:</source>
        <translation>Celgrootte:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="101"/>
        <source>Colors</source>
        <translation>Kleuren</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="107"/>
        <source>Peaks:</source>
        <translation>Pieken:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="139"/>
        <source>Analyzer #1:</source>
        <translation>Analyse #1:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="171"/>
        <source>Background:</source>
        <translation>Achtergrond:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="203"/>
        <source>Analyzer #2:</source>
        <translation>Analyse #2:</translation>
    </message>
    <message>
        <location filename="../analyzersettingsdialog.ui" line="248"/>
        <source>Analyzer #3:</source>
        <translation>Analyse #3:</translation>
    </message>
</context>
<context>
    <name>VisualAnalyzerFactory</name>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="30"/>
        <source>Analyzer Plugin</source>
        <translation>Analyseplug-in</translation>
    </message>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="49"/>
        <source>About Analyzer Visual Plugin</source>
        <translation>Over de Visuele Analyse-plug-in</translation>
    </message>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="50"/>
        <source>Qmmp Analyzer Visual Plugin</source>
        <translation>Visuele Analyse-plug-in voor Qmmp</translation>
    </message>
    <message>
        <location filename="../visualanalyzerfactory.cpp" line="51"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Auteur: Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
</context>
</TS>
