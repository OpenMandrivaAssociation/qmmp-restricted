<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>ProjectM4Widget</name>
    <message>
        <location filename="../projectm4window.cpp" line="165"/>
        <source>&amp;Show Menu</source>
        <translation>&amp;Показать меню</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="165"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="167"/>
        <source>&amp;Next Preset</source>
        <translation>&amp;Следующая предустановка</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="167"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="168"/>
        <source>&amp;Previous Preset</source>
        <translation>&amp;Предыдущая предустановка</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="168"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="169"/>
        <source>&amp;Shuffle</source>
        <translation>&amp;В случайном порядке</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="169"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="170"/>
        <source>&amp;Lock Preset</source>
        <translation>&amp;Заблокировать предустановку</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="170"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="172"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Полноэкранный режим</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="172"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>ProjectMPlugin</name>
    <message>
        <location filename="../projectmplugin.cpp" line="42"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
</context>
<context>
    <name>ProjectMWidget</name>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <location filename="../projectmwidget.cpp" line="160"/>
        <source>&amp;Help</source>
        <translation>&amp;Справка</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <location filename="../projectmwidget.cpp" line="160"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <location filename="../projectmwidget.cpp" line="161"/>
        <source>&amp;Show Song Title</source>
        <translation>&amp;Показать название песни</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <location filename="../projectmwidget.cpp" line="161"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="150"/>
        <location filename="../projectmwidget.cpp" line="162"/>
        <source>&amp;Show Preset Name</source>
        <translation>&amp;Показать имя предустановки</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="150"/>
        <location filename="../projectmwidget.cpp" line="162"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <location filename="../projectmwidget.cpp" line="163"/>
        <source>&amp;Show Menu</source>
        <translation>&amp;Показать меню</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <location filename="../projectmwidget.cpp" line="163"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <location filename="../projectmwidget.cpp" line="165"/>
        <source>&amp;Next Preset</source>
        <translation>&amp;Следующая предустановка</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <location filename="../projectmwidget.cpp" line="165"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="154"/>
        <location filename="../projectmwidget.cpp" line="166"/>
        <source>&amp;Previous Preset</source>
        <translation>&amp;Предыдущая предустановка</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="154"/>
        <location filename="../projectmwidget.cpp" line="166"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="155"/>
        <location filename="../projectmwidget.cpp" line="167"/>
        <source>&amp;Random Preset</source>
        <translation>&amp;Случайная предустановка</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="155"/>
        <location filename="../projectmwidget.cpp" line="167"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="156"/>
        <location filename="../projectmwidget.cpp" line="168"/>
        <source>&amp;Lock Preset</source>
        <translation>&amp;Заблокировать предустановку</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="156"/>
        <location filename="../projectmwidget.cpp" line="168"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="158"/>
        <location filename="../projectmwidget.cpp" line="170"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Полноэкранный режим</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="158"/>
        <location filename="../projectmwidget.cpp" line="170"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>VisualProjectMFactory</name>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="30"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="50"/>
        <source>About ProjectM Visual Plugin</source>
        <translation>О модуле ProjectM для Qmmp</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="51"/>
        <source>Qmmp ProjectM Visual Plugin</source>
        <translation>Модуль projectM для Qmmp</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="52"/>
        <source>This plugin adds projectM visualization</source>
        <translation>Этот модуль добавляет визуализацию projectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="53"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>Разработчик: Илья Котов &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="54"/>
        <source>Based on libprojectM-qt library</source>
        <translation>Основан на базе библиотеки libprojectM-qt</translation>
    </message>
</context>
</TS>
