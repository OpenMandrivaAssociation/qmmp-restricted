<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko">
<context>
    <name>ProjectM4Widget</name>
    <message>
        <location filename="../projectm4window.cpp" line="165"/>
        <source>&amp;Show Menu</source>
        <translation>메뉴 표시(&amp;S)</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="165"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="167"/>
        <source>&amp;Next Preset</source>
        <translation>다음 프리셋(&amp;N)</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="167"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="168"/>
        <source>&amp;Previous Preset</source>
        <translation>이전 프리셋(&amp;P)</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="168"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="169"/>
        <source>&amp;Shuffle</source>
        <translation>순서섞기(&amp;S)</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="169"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="170"/>
        <source>&amp;Lock Preset</source>
        <translation>프리셋 잠금(&amp;L)</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="170"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="172"/>
        <source>&amp;Fullscreen</source>
        <translation>전체화면(&amp;F))</translation>
    </message>
    <message>
        <location filename="../projectm4window.cpp" line="172"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>ProjectMPlugin</name>
    <message>
        <location filename="../projectmplugin.cpp" line="42"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
</context>
<context>
    <name>ProjectMWidget</name>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <location filename="../projectmwidget.cpp" line="160"/>
        <source>&amp;Help</source>
        <translation>도움말(&amp;H)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="148"/>
        <location filename="../projectmwidget.cpp" line="160"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <location filename="../projectmwidget.cpp" line="161"/>
        <source>&amp;Show Song Title</source>
        <translation>곡 제목 표시(&amp;S)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="149"/>
        <location filename="../projectmwidget.cpp" line="161"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="150"/>
        <location filename="../projectmwidget.cpp" line="162"/>
        <source>&amp;Show Preset Name</source>
        <translation>프리셋 이름 표시(&amp;S)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="150"/>
        <location filename="../projectmwidget.cpp" line="162"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <location filename="../projectmwidget.cpp" line="163"/>
        <source>&amp;Show Menu</source>
        <translation>메뉴 표시(&amp;S)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="151"/>
        <location filename="../projectmwidget.cpp" line="163"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <location filename="../projectmwidget.cpp" line="165"/>
        <source>&amp;Next Preset</source>
        <translation>다음 프리셋(&amp;N)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="153"/>
        <location filename="../projectmwidget.cpp" line="165"/>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="154"/>
        <location filename="../projectmwidget.cpp" line="166"/>
        <source>&amp;Previous Preset</source>
        <translation>이전 프리셋(&amp;P)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="154"/>
        <location filename="../projectmwidget.cpp" line="166"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="155"/>
        <location filename="../projectmwidget.cpp" line="167"/>
        <source>&amp;Random Preset</source>
        <translation>프리셋 무작위 선택(&amp;R)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="155"/>
        <location filename="../projectmwidget.cpp" line="167"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="156"/>
        <location filename="../projectmwidget.cpp" line="168"/>
        <source>&amp;Lock Preset</source>
        <translation>프리셋 잠금(&amp;L)</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="156"/>
        <location filename="../projectmwidget.cpp" line="168"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="158"/>
        <location filename="../projectmwidget.cpp" line="170"/>
        <source>&amp;Fullscreen</source>
        <translation>전체화면(&amp;F))</translation>
    </message>
    <message>
        <location filename="../projectmwidget.cpp" line="158"/>
        <location filename="../projectmwidget.cpp" line="170"/>
        <source>F</source>
        <translation>F</translation>
    </message>
</context>
<context>
    <name>VisualProjectMFactory</name>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="30"/>
        <source>ProjectM</source>
        <translation>ProjectM</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="50"/>
        <source>About ProjectM Visual Plugin</source>
        <translation>ProjectM 시각 플러그인 정보</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="51"/>
        <source>Qmmp ProjectM Visual Plugin</source>
        <translation>Qmmp ProjectM 시각 플러그인</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="52"/>
        <source>This plugin adds projectM visualization</source>
        <translation>이 플러그인은 projectM 시각화를 추가합니다</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="53"/>
        <source>Written by: Ilya Kotov &lt;forkotov02@ya.ru&gt;</source>
        <translation>작성자: Ilya Kotov &lt;forkotov02@ya.ru&gt;</translation>
    </message>
    <message>
        <location filename="../visualprojectmfactory.cpp" line="54"/>
        <source>Based on libprojectM-qt library</source>
        <translation>libproject M-qt 라이브러리에 기반함</translation>
    </message>
</context>
</TS>
