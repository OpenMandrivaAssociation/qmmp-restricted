/***************************************************************************
 *   Copyright (C) 2009-2026 by Ilya Kotov                                 *
 *   forkotov02@ya.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.         *
 ***************************************************************************/
#ifndef PROJECTMPLUGIN_H
#define PROJECTMPLUGIN_H

#include <QWidget>
#include <QTime>
#include <qmmp/visual.h>

class QTimer;
class QSplitter;
class Buffer;
#ifdef PROJECTM_4
class ProjectM4Widget;
#else
class ProjectMWidget;
#endif

class ProjectMPlugin : public Visual
{
    Q_OBJECT
public:
    ProjectMPlugin(QWidget *parent = nullptr);
    virtual ~ProjectMPlugin();

public slots:
    void start() override;
    void stop() override;

private slots:
    void onTimeout();
    void setFullScreen(bool yes);

private:
    void closeEvent(QCloseEvent *event) override;
    void showEvent(QShowEvent *) override;
    void hideEvent(QHideEvent *) override;
    QTimer *m_timer;
#ifdef PROJECTM_4
    ProjectM4Widget *m_projectMWidget;
#else
    ProjectMWidget *m_projectMWidget;
#endif
    QSplitter *m_splitter;
    float m_left[QMMP_VISUAL_NODE_SIZE];
    float m_right[QMMP_VISUAL_NODE_SIZE];
};


#endif
