<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja">
<context>
    <name>SeekOption</name>
    <message>
        <location filename="../seekoption.cpp" line="29"/>
        <source>Seek to position in the current track</source>
        <translation>現在のトラック内の指定位置にシーク</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="30"/>
        <source>Seek forward</source>
        <translation>前方にシーク</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="31"/>
        <source>Seek backwards</source>
        <translation>後方にシーク</translation>
    </message>
    <message>
        <location filename="../seekoption.cpp" line="64"/>
        <source>Invalid position specified</source>
        <translation>指定された位置が無効です</translation>
    </message>
</context>
</TS>
