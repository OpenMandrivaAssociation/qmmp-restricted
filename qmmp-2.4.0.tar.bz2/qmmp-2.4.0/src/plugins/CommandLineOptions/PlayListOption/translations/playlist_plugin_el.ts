<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="el">
<context>
    <name>PlayListOption</name>
    <message>
        <location filename="../playlistoption.cpp" line="33"/>
        <source>Show playlist manipulation commands</source>
        <translation>Εμφάνιση των εντολών χειρισμού της λίστας αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="34"/>
        <source>List all available playlists</source>
        <translation>Εμφάνιση όλων των διαθέσιμων λιστών αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="35"/>
        <source>Show playlist content</source>
        <translation>Εμφάνιση του περιεχομένου της λίστας αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="36"/>
        <source>Select playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="37"/>
        <source>Create playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="38"/>
        <source>Play track in the specified playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="39"/>
        <source>Clear playlist</source>
        <translation>Καθαρισμός της λίστας αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="40"/>
        <source>Remove playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="41"/>
        <source>Activate next playlist</source>
        <translation>Ενεργοποίηση του επόμενου κατάστιχου αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="42"/>
        <source>Activate previous playlist</source>
        <translation>Ενεργοποίηση του προηγούμενου κατάστιχου αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="43"/>
        <source>Toggle playlist repeat</source>
        <translation>Εναλλαγή επανάληψης της λίστας αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="44"/>
        <source>Toggle playlist shuffle</source>
        <translation>Εναλλαγή ανακατέματος της λίστας αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="45"/>
        <source>Show playlist options</source>
        <translation>Εμφάνιση των επιλογών της λίστας αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="94"/>
        <source>Arguments:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="95"/>
        <source>%1 - index or name of the playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="96"/>
        <source>%1 - index of the track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="97"/>
        <source>%1 - name of the new playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="118"/>
        <location filename="../playlistoption.cpp" line="135"/>
        <location filename="../playlistoption.cpp" line="160"/>
        <location filename="../playlistoption.cpp" line="199"/>
        <location filename="../playlistoption.cpp" line="213"/>
        <source>Invalid playlist ID</source>
        <translation>Μη έγκυρο αναγνωριστικό της λίστας αναπαραγωγής</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="142"/>
        <source>Invalid playlist name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="147"/>
        <source>Playlist with name &quot;%1&quot; already exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="156"/>
        <source>Invalid number of arguments</source>
        <translation>Μη έγκυρος αριθμός ορισμάτων</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="165"/>
        <source>Invalid track ID</source>
        <translation>Μη έγκυρο αναγνωριστικό κομματιού</translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="206"/>
        <source>Unable to remove last remaining playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistoption.cpp" line="209"/>
        <source>Missing playlist ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
